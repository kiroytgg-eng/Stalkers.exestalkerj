# Stalkers.exe 1.2.1 (Minecraft 1.20.1 / Forge 47.4.0)

## Compilar (genera el .jar)
1. Instala **JDK 17** y conexion a internet.
2. Descarga el **Forge MDK 1.20.1-47.4.0** (files.minecraftforge.net) y copia de el estos archivos a esta carpeta:
   `gradlew`, `gradlew.bat` y la carpeta `gradle/` (contiene el wrapper).
   (Alternativa: con Gradle 8.1.1 instalado, ejecuta `gradle wrapper --gradle-version 8.1.1`.)
3. Ejecuta:
   - Windows: `gradlew.bat build`
   - Linux/Mac: `./gradlew build`
4. El mod queda en `build/libs/stalkers_exe-1.2.1.jar`. Copialo a la carpeta `mods` de Minecraft 1.20.1 con Forge.

## Ajustes
- Archivo: `config/stalkers_exe-common.toml` (se crea al abrir el juego una vez)
  - `danger` (0-100, por defecto **50**): agresividad y capacidad de acecho
  - `directorEnabled`, `maxPerPlayer`, `autoHunterRun`
  - `hunter_run`: `countdownSeconds` (150), `retryTicks` (10), `lethal` (true)
- En juego: `/stalker danger 75`

## Comandos (requieren permiso 2)
- `/stalker help`
- `/stalker danger [0-100]`
- `/stalker spawn <hunter|stalker|seeker|hunter_run> [jugador]`
- `/stalker event hunter_run [jugador]`
- `/stalker clear`

## Criaturas
| Tipo | Habilidad unica |
|---|---|
| Hunter (Cazador) | Se congela si lo miras; si apartas la vista tras mirarlo mucho, se lanza. Oscuridad al golpear. |
| Stalker (Acechador) | Se teletransporta tras tu espalda. Ralentiza al golpear. |
| Seeker (Buscador) | Sigue ruidos (picar, correr). Ciega al golpear; se desliza lejos si lo golpeas. |
| Hunter Run | Carrera muy rapida y letal. El evento reintenta aparecer hasta lograrlo. |

## Peligro 0-100
Escala velocidad, dano, distancia de deteccion, rapidez del acecho, frecuencia de apariciones y del evento automatico.
0 = solo observan, nunca atacan ni aparecen solos.
