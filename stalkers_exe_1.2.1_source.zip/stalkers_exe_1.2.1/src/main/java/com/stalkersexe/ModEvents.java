package com.stalkersexe;

import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import com.stalkersexe.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = StalkersMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        for (StalkerKind k : StalkerKind.values()) {
            event.put(ModEntities.TYPES.get(k).get(), StalkerEntity.createAttributes(k).build());
        }
    }
}
