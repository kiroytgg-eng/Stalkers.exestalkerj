package com.stalkersexe;

import com.stalkersexe.registry.ModEntities;
import com.stalkersexe.registry.ModSounds;
import com.stalkersexe.server.StalkerConfig;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(StalkersMod.MODID)
public class StalkersMod {
    public static final String MODID = "stalkers_exe";

    public StalkersMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, StalkerConfig.SPEC);
    }
}
