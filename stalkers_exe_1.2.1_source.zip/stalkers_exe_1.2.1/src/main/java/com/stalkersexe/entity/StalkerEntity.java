package com.stalkersexe.entity;

import com.stalkersexe.registry.ModSounds;
import com.stalkersexe.server.StalkerConfig;
import com.stalkersexe.server.StalkerPlacement;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/** Entidad unica para los 4 tipos; el comportamiento depende de {@link StalkerKind}. */
public class StalkerEntity extends Monster {
    public static final int ANIM_STALK = 0;
    public static final int ANIM_CHASE = 1;
    public static final int ANIM_WATCHED = 2;
    public static final int ANIM_SEARCH = 4;

    private static final EntityDataAccessor<Integer> ANIM =
            SynchedEntityData.defineId(StalkerEntity.class, EntityDataSerializers.INT);

    private final StalkerKind kind;
    private UUID targetPlayer;
    private int lifetime;

    public StalkerEntity(EntityType<? extends StalkerEntity> type, Level level, StalkerKind kind) {
        super(type, level);
        this.kind = kind;
        this.xpReward = 0;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes(StalkerKind k) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, k.health)
                .add(Attributes.MOVEMENT_SPEED, k.speed)
                .add(Attributes.ATTACK_DAMAGE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 96.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ANIM, ANIM_STALK);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new StalkerBrainGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6));
    }

    public StalkerKind kind() {
        return kind;
    }

    public int getAnimState() {
        return this.entityData.get(ANIM);
    }

    public void setAnimState(int s) {
        if (getAnimState() != s) this.entityData.set(ANIM, s);
    }

    public void setTargetPlayer(UUID id) {
        this.targetPlayer = id;
    }

    public UUID getTargetPlayer() {
        return targetPlayer;
    }

    // ---------- percepcion ----------

    /** True si el jugador tiene a la criatura en su campo de vision. */
    public boolean isWatchedBy(Player p) {
        Vec3 look = p.getViewVector(1.0F).normalize();
        Vec3 to = new Vec3(getX() - p.getX(), getEyeY() - p.getEyeY(), getZ() - p.getZ());
        if (to.lengthSqr() < 1.0E-4) return true;
        to = to.normalize();
        return look.dot(to) > 0.6 && p.hasLineOfSight(this);
    }

    // ---------- habilidades ----------

    /** Teletransporte corto cerca (o detras) del jugador. */
    public boolean blinkNear(Player p, double minD, double maxD, boolean behind) {
        boolean ok = StalkerPlacement.place(this, p, minD, maxD, behind, 14);
        if (ok) getNavigation().stop();
        return ok;
    }

    public void strike(Player p, double danger01) {
        if (danger01 <= 0.0) return;
        float dmg = (float) (kind.damage * (0.6 + 1.2 * danger01));
        if (kind == StalkerKind.HUNTER_RUN && StalkerConfig.HUNTER_RUN_LETHAL.get()) dmg = 1000.0F;
        this.swing(InteractionHand.MAIN_HAND);
        boolean hit = p.hurt(this.damageSources().mobAttack(this), dmg);
        if (!hit) return;
        playLocal("loud_bone_crack", 1.0F, 1.0F);
        int scale = (int) (1 + danger01 * 2);
        switch (kind) {
            case HUNTER -> p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60 * scale, 0, false, false, false));
            case STALKER -> p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50 * scale, 1, false, false, false));
            case SEEKER -> {
                p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40 * scale, 0, false, false, false));
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60 * scale, 0, false, false, false));
            }
            default -> { }
        }
    }

    // ---------- sonido ----------

    public void playLocal(String name, float vol, float pitch) {
        this.level().playSound(null, getX(), getY(), getZ(), ModSounds.get(name), SoundSource.HOSTILE, vol, pitch);
    }

    public void playTo(Player p, String name, float vol) {
        if (p instanceof ServerPlayer sp) {
            sp.playNotifySound(ModSounds.get(name), SoundSource.HOSTILE, vol, 1.0F);
        }
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(ModSounds.get(random.nextBoolean() ? "es_step1" : "es_step2"), 0.5F, 1.0F);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource src) {
        return ModSounds.get("bonecracked");
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.get("es_glitch");
    }

    // ---------- ciclo de vida ----------

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        lifetime++;
        if (tickCount % 40 == 1) applyDangerScaling();
        if (tickCount % 100 == 0) {
            Player near = this.level().getNearestPlayer(this, 128.0);
            int max = kind == StalkerKind.HUNTER_RUN ? 20 * 90 : 20 * 60 * 8;
            boolean tooOld = lifetime > max;
            if (near == null || (tooOld && (kind == StalkerKind.HUNTER_RUN || near.distanceTo(this) > 12.0F))) {
                this.discard();
            }
        }
    }

    /** La velocidad depende del peligro (se actualiza en vivo si cambias el ajuste). */
    private void applyDangerScaling() {
        double d = StalkerConfig.danger01();
        double mul = kind == StalkerKind.HUNTER_RUN ? 0.85 + 0.30 * d : 0.75 + 0.85 * d;
        var attr = getAttribute(Attributes.MOVEMENT_SPEED);
        if (attr != null) attr.setBaseValue(kind.speed * mul);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean r = super.hurt(source, amount);
        if (r && !this.level().isClientSide && kind == StalkerKind.SEEKER
                && source.getEntity() instanceof Player pl && StalkerConfig.danger() > 0) {
            // El Buscador se desliza lejos tras recibir un golpe
            if (blinkNear(pl, 14, 22, false)) playLocal("es_teleport", 1.0F, 0.8F);
        }
        return r;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (kind == StalkerKind.HUNTER_RUN && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true;
        return super.isInvulnerableTo(source);
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }
}
