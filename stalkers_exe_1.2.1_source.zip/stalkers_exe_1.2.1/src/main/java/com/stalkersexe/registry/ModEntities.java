package com.stalkersexe.registry;

import com.stalkersexe.StalkersMod;
import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, StalkersMod.MODID);

    public static final Map<StalkerKind, RegistryObject<EntityType<StalkerEntity>>> TYPES =
            new EnumMap<>(StalkerKind.class);

    static {
        for (StalkerKind k : StalkerKind.values()) {
            TYPES.put(k, ENTITIES.register(k.id, () ->
                    EntityType.Builder.<StalkerEntity>of((type, level) -> new StalkerEntity(type, level, k),
                                    MobCategory.MONSTER)
                            .sized(0.7f, 2.0f)
                            .clientTrackingRange(12)
                            .fireImmune()
                            .build(StalkersMod.MODID + ":" + k.id)));
        }
    }

    private ModEntities() {}
}
