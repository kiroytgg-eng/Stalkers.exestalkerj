package com.stalkersexe.registry;

import com.stalkersexe.StalkersMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.HashMap;
import java.util.Map;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StalkersMod.MODID);

    private static final String[] NAMES = {
            "alternate_jumpscare", "bonecracked", "break_event_1", "break_event_2", "break_event_3", "break_event_4",
            "cave_jumpscare", "cave_mine", "door_knock", "es_chase1", "es_glitch", "es_near", "es_step1", "es_step2",
            "es_teleport", "hole_scream", "hunt_chase", "hunt_glance", "hunt_music_box", "hunt_run_pulse",
            "hunt_run_warn", "hunt_tension", "iknowyourhere", "knock_glass_scare", "knock_scream", "knock_smash",
            "knock_spotted", "loud_bone_crack", "machinerunningsounds", "pulse", "pulse_fast", "underbed_1",
            "underbed_2", "whispering", "win_knock_loop", "win_peek_spotted", "win_peek_start"
    };

    private static final Map<String, RegistryObject<SoundEvent>> MAP = new HashMap<>();

    static {
        for (String n : NAMES) {
            MAP.put(n, SOUNDS.register(n,
                    () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(StalkersMod.MODID, n))));
        }
    }

    public static SoundEvent get(String name) {
        return MAP.get(name).get();
    }

    private ModSounds() {}
}
