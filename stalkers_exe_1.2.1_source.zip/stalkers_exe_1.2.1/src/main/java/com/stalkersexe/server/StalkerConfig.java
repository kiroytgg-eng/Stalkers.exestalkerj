package com.stalkersexe.server;

import net.minecraftforge.common.ForgeConfigSpec;

/** Ajustes del mod: config/stalkers_exe-common.toml */
public final class StalkerConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue DANGER;
    public static final ForgeConfigSpec.BooleanValue DIRECTOR_ENABLED;
    public static final ForgeConfigSpec.IntValue MAX_PER_PLAYER;
    public static final ForgeConfigSpec.BooleanValue AUTO_HUNTER_RUN;
    public static final ForgeConfigSpec.IntValue HUNTER_RUN_SECONDS;
    public static final ForgeConfigSpec.IntValue HUNTER_RUN_RETRY_TICKS;
    public static final ForgeConfigSpec.BooleanValue HUNTER_RUN_LETHAL;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("general");
        DANGER = b.comment("Nivel de peligro 0-100 (por defecto 50).",
                        "0 = los stalkers solo observan y nunca atacan ni aparecen solos.",
                        "100 = maxima agresividad, velocidad, dano y capacidad de acecho.")
                .defineInRange("danger", 50, 0, 100);
        DIRECTOR_ENABLED = b.comment("Aparicion automatica de stalkers cerca de los jugadores.")
                .define("directorEnabled", true);
        MAX_PER_PLAYER = b.comment("Maximo base de stalkers por jugador (sube con el peligro).")
                .defineInRange("maxPerPlayer", 1, 1, 10);
        b.pop();
        b.push("hunter_run");
        AUTO_HUNTER_RUN = b.comment("El evento hunter_run puede empezar solo (mas probable con mas peligro).")
                .define("autoHunterRun", true);
        HUNTER_RUN_SECONDS = b.comment("Segundos de cuenta atras antes de que aparezca el Hunter Run.")
                .defineInRange("countdownSeconds", 150, 5, 3600);
        HUNTER_RUN_RETRY_TICKS = b.comment("Cada cuantos ticks reintenta aparecer hasta conseguirlo.")
                .defineInRange("retryTicks", 10, 1, 200);
        HUNTER_RUN_LETHAL = b.comment("Si es true, el Hunter Run mata de un golpe al atrapar.")
                .define("lethal", true);
        b.pop();
        SPEC = b.build();
    }

    public static int danger() {
        try {
            return Math.max(0, Math.min(100, DANGER.get()));
        } catch (Exception e) {
            return 50;
        }
    }

    /** Peligro normalizado 0.0 - 1.0 */
    public static double danger01() {
        return danger() / 100.0;
    }

    private StalkerConfig() {}
}
