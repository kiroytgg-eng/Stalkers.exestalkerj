package com.stalkersexe.server;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Busca un sitio valido cerca (o detras) de un jugador y mueve la entidad ahi. */
public final class StalkerPlacement {

    public static boolean place(Entity e, Player p, double minD, double maxD, boolean behind, int attempts) {
        Level lvl = p.level();
        RandomSource r = lvl.random;
        double yawRad = Math.toRadians(p.getYRot());
        double baseAng = Math.atan2(-Math.cos(yawRad), Math.sin(yawRad)); // direccion "detras" del jugador
        for (int i = 0; i < attempts; i++) {
            double ang = behind ? baseAng + (r.nextDouble() - 0.5) * 1.4 : r.nextDouble() * Math.PI * 2.0;
            double dist = minD + r.nextDouble() * Math.max(0.0, maxD - minD);
            double x = p.getX() + Math.cos(ang) * dist;
            double z = p.getZ() + Math.sin(ang) * dist;
            Double y = findStandY(lvl, x, p.getY(), z);
            if (y == null) continue;
            double ox = e.getX(), oy = e.getY(), oz = e.getZ();
            float oyaw = e.getYRot();
            e.moveTo(x, y, z, oyaw, 0.0F);
            if (lvl.noCollision(e) && lvl.getFluidState(BlockPos.containing(x, y, z)).isEmpty()) {
                double dx = p.getX() - x;
                double dz = p.getZ() - z;
                e.setYRot((float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F);
                return true;
            }
            e.moveTo(ox, oy, oz, oyaw, 0.0F);
        }
        return false;
    }

    private static Double findStandY(Level lvl, double x, double baseY, double z) {
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        int start = Mth.floor(baseY) + 4;
        int min = Math.max(lvl.getMinBuildHeight() + 1, Mth.floor(baseY) - 8);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        if (!lvl.hasChunkAt(m.set(bx, start, bz))) return null;
        for (int y = start; y >= min; y--) {
            m.set(bx, y - 1, bz);
            BlockState below = lvl.getBlockState(m);
            if (below.getCollisionShape(lvl, m).isEmpty()) continue;
            boolean free = true;
            for (int dy = 0; dy < 3 && free; dy++) {
                m.set(bx, y + dy, bz);
                if (!lvl.getBlockState(m).getCollisionShape(lvl, m).isEmpty()) free = false;
            }
            if (free) return (double) y;
        }
        return null;
    }

    private StalkerPlacement() {}
}
