package com.stalkersexe.server;

import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import com.stalkersexe.registry.ModEntities;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

public final class StalkerSpawner {

    /** Intenta crear una criatura cerca del jugador. Devuelve null si no hubo sitio. */
    public static StalkerEntity spawn(ServerPlayer p, StalkerKind kind, boolean behind,
                                      double minD, double maxD, int attempts) {
        ServerLevel lvl = p.serverLevel();
        StalkerEntity e = ModEntities.TYPES.get(kind).get().create(lvl);
        if (e == null) return null;
        if (!StalkerPlacement.place(e, p, minD, maxD, behind, attempts)) {
            e.discard();
            return null;
        }
        if (kind == StalkerKind.HUNTER_RUN) e.setTargetPlayer(p.getUUID());
        lvl.addFreshEntity(e);
        return e;
    }

    public static StalkerEntity spawn(ServerPlayer p, StalkerKind kind) {
        return spawn(p, kind, true, 14.0, 24.0, 24);
    }

    private StalkerSpawner() {}
}
